import React from 'react'

const Header = () => (
  <header>
    <h1 className="header">Embla Carousel Loop React</h1>
  </header>
)

export default Header
